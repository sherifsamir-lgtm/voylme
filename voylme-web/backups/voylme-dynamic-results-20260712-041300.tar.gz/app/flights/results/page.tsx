"use client";

import {
  Suspense,
  useMemo,
  useState,
} from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  ArrowLeft,
  ChevronDown,
  Clock3,
  Luggage,
  Plane,
  SlidersHorizontal,
} from "lucide-react";

type SortOption = "best" | "cheapest" | "fastest";

type FlightTemplate = {
  id: number;
  airline: string;
  code: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  durationMinutes: number;
  stops: string;
  baggage: string;
  baseFare: number;
  taxes: number;
  serviceFee: number;
  recommended?: boolean;
};

type Flight = FlightTemplate & {
  from: string;
  to: string;
  total: number;
};

const flightTemplates: FlightTemplate[] = [
  {
    id: 1,
    airline: "Emirates",
    code: "EK 927",
    departureTime: "08:15",
    arrivalTime: "10:25",
    duration: "4h 10m",
    durationMinutes: 250,
    stops: "Direct",
    baggage: "25 kg",
    baseFare: 995,
    taxes: 200,
    serviceFee: 50,
    recommended: true,
  },
  {
    id: 2,
    airline: "EgyptAir",
    code: "MS 911",
    departureTime: "11:30",
    arrivalTime: "13:50",
    duration: "4h 20m",
    durationMinutes: 260,
    stops: "Direct",
    baggage: "23 kg",
    baseFare: 880,
    taxes: 165,
    serviceFee: 50,
  },
  {
    id: 3,
    airline: "Qatar Airways",
    code: "QR 1007",
    departureTime: "14:10",
    arrivalTime: "18:45",
    duration: "6h 35m",
    durationMinutes: 395,
    stops: "1 stop",
    baggage: "25 kg",
    baseFare: 930,
    taxes: 200,
    serviceFee: 50,
  },
  {
    id: 4,
    airline: "Etihad Airways",
    code: "EY 655",
    departureTime: "18:25",
    arrivalTime: "20:40",
    duration: "4h 15m",
    durationMinutes: 255,
    stops: "Direct",
    baggage: "23 kg",
    baseFare: 1050,
    taxes: 220,
    serviceFee: 50,
  },
];

function formatSearchDate(value: string | null) {
  if (!value) return "Select date";

  const date = new Date(`${value}T12:00:00`);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(date);
}

function passengerText(
  adults: number,
  children: number,
  infants: number
) {
  const total = adults + children + infants;

  return `${total} ${
    total === 1 ? "passenger" : "passengers"
  }`;
}

function FlightResultsContent() {
  const searchParams = useSearchParams();

  const [sortBy, setSortBy] =
    useState<SortOption>("best");

  const [showFilters, setShowFilters] =
    useState(false);

  const from =
    searchParams.get("from")?.toUpperCase() || "DXB";

  const to =
    searchParams.get("to")?.toUpperCase() || "CAI";

  const fromCity =
    searchParams.get("fromCity") || from;

  const toCity =
    searchParams.get("toCity") || to;

  const departureDate =
    searchParams.get("departureDate");

  const returnDate =
    searchParams.get("returnDate");

  const tripType =
    searchParams.get("tripType") || "one-way";

  const adults = Math.max(
    1,
    Number(searchParams.get("adults") || "1")
  );

  const children = Math.max(
    0,
    Number(searchParams.get("children") || "0")
  );

  const infants = Math.max(
    0,
    Number(searchParams.get("infants") || "0")
  );

  const cabinClass =
    searchParams.get("cabinClass") || "Economy";

  const flights = useMemo<Flight[]>(
    () =>
      flightTemplates.map((flight) => ({
        ...flight,
        from,
        to,
        total:
          flight.baseFare +
          flight.taxes +
          flight.serviceFee,
      })),
    [from, to]
  );

  const sortedFlights = useMemo(() => {
    return [...flights].sort((a, b) => {
      if (sortBy === "cheapest") {
        return a.total - b.total;
      }

      if (sortBy === "fastest") {
        return (
          a.durationMinutes - b.durationMinutes
        );
      }

      return (
        Number(Boolean(b.recommended)) -
        Number(Boolean(a.recommended))
      );
    });
  }, [flights, sortBy]);

  function createFlightDetailsUrl(flight: Flight) {
    const params = new URLSearchParams({
      tripType,
      from,
      fromCity,
      to,
      toCity,
      departureDate: departureDate || "",
      adults: String(adults),
      children: String(children),
      infants: String(infants),
      cabinClass,
      airline: flight.airline,
      flightCode: flight.code,
      departureTime: flight.departureTime,
      arrivalTime: flight.arrivalTime,
      duration: flight.duration,
      stops: flight.stops,
      baggage: flight.baggage,
      baseFare: String(flight.baseFare),
      taxes: String(flight.taxes),
      serviceFee: String(flight.serviceFee),
      total: String(flight.total),
    });

    if (tripType === "round-trip" && returnDate) {
      params.set("returnDate", returnDate);
    }

    return `/flights/results/${flight.id}?${params.toString()}`;
  }

  const editSearchParams =
    searchParams.toString();

  return (
    <main className="min-h-screen bg-[#f7f5f6] pb-8">
      <header className="sticky top-0 z-40 border-b border-gray-200 bg-white">
        <div className="mx-auto flex h-[68px] w-full max-w-[430px] items-center justify-between px-4">
          <Link
            href={`/search${editSearchParams ? `?${editSearchParams}` : ""}`}
            aria-label="Back to search"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-[#660033]/20 text-[#660033]"
          >
            <ArrowLeft size={21} />
          </Link>

          <div className="text-center">
            <h1 className="text-[18px] font-extrabold text-[#660033]">
              Flight Results
            </h1>

            <p className="text-[11px] text-gray-500">
              {fromCity} to {toCity}
            </p>
          </div>

          <button
            type="button"
            onClick={() =>
              setShowFilters((current) => !current)
            }
            aria-label="Open filters"
            className="flex h-10 w-10 items-center justify-center rounded-full bg-[#660033] text-white"
          >
            <SlidersHorizontal size={19} />
          </button>
        </div>
      </header>

      <div className="mx-auto w-full max-w-[430px] px-4 pt-4">
        <section className="rounded-[22px] bg-[#660033] p-4 text-white shadow-md">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[11px] text-white/75">
                Your search
              </p>

              <p className="mt-1 truncate text-[16px] font-bold">
                {from} → {to}
              </p>

              <p className="mt-1 text-[11px] leading-5 text-white/80">
                {formatSearchDate(departureDate)}
                {tripType === "round-trip" && returnDate
                  ? ` · Return ${formatSearchDate(returnDate)}`
                  : ""}
                {" · "}
                {passengerText(adults, children, infants)}
                {" · "}
                {cabinClass}
              </p>
            </div>

            <Link
              href={`/search${editSearchParams ? `?${editSearchParams}` : ""}`}
              className="shrink-0 rounded-full border border-white/40 px-4 py-2 text-[12px] font-bold"
            >
              Edit
            </Link>
          </div>
        </section>

        {showFilters && (
          <section className="mt-3 rounded-[20px] border border-gray-200 bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-[#660033]">
                Filters
              </h2>

              <button
                type="button"
                onClick={() => setShowFilters(false)}
                className="text-[12px] font-semibold text-gray-500"
              >
                Close
              </button>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-2">
              <button
                type="button"
                className="rounded-[14px] border border-[#660033]/25 px-3 py-3 text-left text-[12px] font-semibold text-[#660033]"
              >
                Direct flights
              </button>

              <button
                type="button"
                className="rounded-[14px] border border-[#660033]/25 px-3 py-3 text-left text-[12px] font-semibold text-[#660033]"
              >
                Baggage included
              </button>

              <button
                type="button"
                className="rounded-[14px] border border-[#660033]/25 px-3 py-3 text-left text-[12px] font-semibold text-[#660033]"
              >
                Morning flights
              </button>

              <button
                type="button"
                className="rounded-[14px] border border-[#660033]/25 px-3 py-3 text-left text-[12px] font-semibold text-[#660033]"
              >
                Under AED 1,300
              </button>
            </div>
          </section>
        )}

        <section className="mt-4 grid grid-cols-3 gap-2">
          {[
            {
              value: "best" as const,
              label: "Best",
            },
            {
              value: "cheapest" as const,
              label: "Cheapest",
            },
            {
              value: "fastest" as const,
              label: "Fastest",
            },
          ].map((option) => (
            <button
              key={option.value}
              type="button"
              onClick={() => setSortBy(option.value)}
              className={[
                "rounded-[16px] border px-2 py-3 text-center transition",
                sortBy === option.value
                  ? "border-[#660033] bg-[#660033] text-white"
                  : "border-gray-200 bg-white text-[#660033]",
              ].join(" ")}
            >
              <span className="block text-[12px] font-bold">
                {option.label}
              </span>
            </button>
          ))}
        </section>

        <div className="mt-4 flex items-center justify-between">
          <p className="text-[13px] font-bold text-slate-800">
            {sortedFlights.length} flights found
          </p>

          <button
            type="button"
            className="flex items-center gap-1 text-[12px] font-semibold text-[#660033]"
          >
            Recommended
            <ChevronDown size={15} />
          </button>
        </div>

        <section className="mt-3 space-y-3">
          {sortedFlights.map((flight) => (
            <article
              key={flight.id}
              className="overflow-hidden rounded-[22px] border border-gray-200 bg-white shadow-sm"
            >
              {flight.recommended && (
                <div className="bg-[#660033] px-4 py-1.5 text-[10px] font-bold text-white">
                  Recommended
                </div>
              )}

              <div className="p-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#660033]/10 text-[#660033]">
                      <Plane size={21} />
                    </div>

                    <div className="min-w-0">
                      <h2 className="truncate text-[14px] font-bold text-slate-900">
                        {flight.airline}
                      </h2>

                      <p className="text-[11px] text-gray-500">
                        {flight.code}
                      </p>
                    </div>
                  </div>

                  <div className="shrink-0 text-right">
                    <p className="text-[10px] text-gray-500">
                      Total
                    </p>

                    <p className="text-[20px] font-black text-[#660033]">
                      AED {flight.total}
                    </p>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-[1fr_auto_1fr] items-center gap-3">
                  <div>
                    <p className="text-[22px] font-extrabold text-slate-900">
                      {flight.departureTime}
                    </p>

                    <p className="text-[12px] font-bold text-gray-500">
                      {flight.from}
                    </p>
                  </div>

                  <div className="min-w-[110px] text-center">
                    <p className="mb-1 text-[10px] text-gray-500">
                      {flight.duration}
                    </p>

                    <div className="relative h-[1px] bg-gray-300">
                      <span className="absolute -left-1 -top-[3px] h-2 w-2 rounded-full bg-[#660033]" />

                      <Plane
                        size={13}
                        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white text-[#660033]"
                      />

                      <span className="absolute -right-1 -top-[3px] h-2 w-2 rounded-full bg-[#660033]" />
                    </div>

                    <p className="mt-1 text-[10px] font-semibold text-[#660033]">
                      {flight.stops}
                    </p>
                  </div>

                  <div className="text-right">
                    <p className="text-[22px] font-extrabold text-slate-900">
                      {flight.arrivalTime}
                    </p>

                    <p className="text-[12px] font-bold text-gray-500">
                      {flight.to}
                    </p>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2 rounded-[16px] bg-[#faf7f9] p-3 text-center">
                  <div>
                    <p className="text-[10px] text-gray-500">
                      Base fare
                    </p>

                    <p className="mt-1 text-[12px] font-bold text-slate-800">
                      AED {flight.baseFare}
                    </p>
                  </div>

                  <div>
                    <p className="text-[10px] text-gray-500">
                      Taxes
                    </p>

                    <p className="mt-1 text-[12px] font-bold text-slate-800">
                      AED {flight.taxes}
                    </p>
                  </div>

                  <div>
                    <p className="text-[10px] text-gray-500">
                      Service
                    </p>

                    <p className="mt-1 text-[12px] font-bold text-slate-800">
                      AED {flight.serviceFee}
                    </p>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-4 border-t border-gray-100 pt-3 text-[11px] text-gray-600">
                  <span className="flex items-center gap-1">
                    <Clock3
                      size={14}
                      className="text-[#660033]"
                    />
                    {flight.duration}
                  </span>

                  <span className="flex items-center gap-1">
                    <Luggage
                      size={14}
                      className="text-[#660033]"
                    />
                    {flight.baggage}
                  </span>
                </div>

                <Link
                  href={createFlightDetailsUrl(flight)}
                  className="mt-4 flex h-[48px] w-full items-center justify-center rounded-full bg-[#660033] text-[14px] font-bold text-white"
                >
                  Select Flight
                </Link>
              </div>
            </article>
          ))}
        </section>
      </div>
    </main>
  );
}

export default function FlightResultsPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center bg-[#f7f5f6]">
          <p className="font-bold text-[#660033]">
            Loading flight results...
          </p>
        </main>
      }
    >
      <FlightResultsContent />
    </Suspense>
  );
}
