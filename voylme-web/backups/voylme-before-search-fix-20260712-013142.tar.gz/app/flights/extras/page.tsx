"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  ArrowLeft,
  Luggage,
  Armchair,
  Utensils,
  ShieldCheck,
  ChevronRight,
  Check,
} from "lucide-react";

type ExtraOption = {
  id: string;
  title: string;
  description: string;
  price: number;
  icon: "baggage" | "seat" | "meal" | "protection";
};

const flightPrices: Record<string, number> = {
  "1": 1245,
  "2": 1095,
  "3": 1180,
  "4": 1320,
};

const extras: ExtraOption[] = [
  {
    id: "baggage",
    title: "Extra baggage",
    description: "Add 10 kg checked baggage",
    price: 120,
    icon: "baggage",
  },
  {
    id: "seat",
    title: "Preferred seat",
    description: "Choose your preferred standard seat",
    price: 45,
    icon: "seat",
  },
  {
    id: "meal",
    title: "Special meal",
    description: "Select a special dietary meal",
    price: 35,
    icon: "meal",
  },
  {
    id: "protection",
    title: "Travel protection",
    description: "Basic trip protection and support",
    price: 75,
    icon: "protection",
  },
];

function ExtraIcon({
  type,
}: {
  type: ExtraOption["icon"];
}) {
  const className = "text-[#660033]";

  if (type === "baggage") {
    return <Luggage size={22} className={className} />;
  }

  if (type === "seat") {
    return <Armchair size={22} className={className} />;
  }

  if (type === "meal") {
    return <Utensils size={22} className={className} />;
  }

  return <ShieldCheck size={22} className={className} />;
}

export default function FlightExtrasPage() {
  const searchParams = useSearchParams();
  const flightId = searchParams.get("flight") ?? "1";

  const basePrice = useMemo(
    () => flightPrices[flightId] ?? flightPrices["1"],
    [flightId]
  );

  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);

  const toggleExtra = (id: string) => {
    setSelectedExtras((current) =>
      current.includes(id)
        ? current.filter((item) => item !== id)
        : [...current, id]
    );
  };

  const extrasTotal = useMemo(
    () =>
      extras
        .filter((extra) => selectedExtras.includes(extra.id))
        .reduce((total, extra) => total + extra.price, 0),
    [selectedExtras]
  );

  const totalPrice = basePrice + extrasTotal;

  return (
    <main className="min-h-screen bg-[#f7f5f6] pb-[116px]">
      <header className="sticky top-0 z-40 border-b border-gray-200 bg-white">
        <div className="mx-auto flex h-[68px] w-full max-w-[430px] items-center justify-between px-4">
          <Link
            href={`/flights/passengers?flight=${flightId}`}
            aria-label="Back to passenger details"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-[#660033]/20 text-[#660033]"
          >
            <ArrowLeft size={21} />
          </Link>

          <div className="text-center">
            <h1 className="text-[18px] font-extrabold text-[#660033]">
              Extras
            </h1>

            <p className="text-[11px] text-gray-500">
              Customize your trip
            </p>
          </div>

          <div className="h-10 w-10" aria-hidden="true" />
        </div>
      </header>

      <div className="mx-auto w-full max-w-[430px] px-4 pt-4">
        <section className="rounded-[22px] bg-[#660033] p-4 text-white shadow-md">
          <p className="text-[11px] text-white/75">
            Current booking
          </p>

          <div className="mt-1 flex items-end justify-between">
            <div>
              <p className="text-[16px] font-bold">
                Dubai to Cairo
              </p>

              <p className="mt-1 text-[11px] text-white/80">
                Flight #{flightId} · 1 passenger
              </p>
            </div>

            <p className="text-[22px] font-black">
              AED {basePrice}
            </p>
          </div>
        </section>

        <section className="mt-4">
          <h2 className="text-[16px] font-extrabold text-slate-900">
            Add optional extras
          </h2>

          <p className="mt-1 text-[11px] text-gray-500">
            Select only what you need
          </p>

          <div className="mt-4 space-y-3">
            {extras.map((extra) => {
              const isSelected = selectedExtras.includes(extra.id);

              return (
                <button
                  key={extra.id}
                  type="button"
                  onClick={() => toggleExtra(extra.id)}
                  className={[
                    "flex w-full items-center justify-between rounded-[22px] border bg-white p-4 text-left shadow-sm transition",
                    isSelected
                      ? "border-[#660033] ring-2 ring-[#660033]/10"
                      : "border-gray-200",
                  ].join(" ")}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#660033]/10">
                      <ExtraIcon type={extra.icon} />
                    </div>

                    <div>
                      <h3 className="text-[14px] font-extrabold text-slate-900">
                        {extra.title}
                      </h3>

                      <p className="mt-1 text-[11px] text-gray-500">
                        {extra.description}
                      </p>
                    </div>
                  </div>

                  <div className="ml-3 text-right">
                    <p className="text-[14px] font-extrabold text-[#660033]">
                      AED {extra.price}
                    </p>

                    <div
                      className={[
                        "ml-auto mt-2 flex h-6 w-6 items-center justify-center rounded-full border",
                        isSelected
                          ? "border-[#660033] bg-[#660033] text-white"
                          : "border-gray-300 bg-white text-transparent",
                      ].join(" ")}
                    >
                      <Check size={15} />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        <section className="mt-4 rounded-[22px] bg-white p-4 shadow-sm">
          <h2 className="text-[15px] font-extrabold text-slate-900">
            Price summary
          </h2>

          <div className="mt-4 space-y-3 text-[12px]">
            <div className="flex items-center justify-between text-gray-600">
              <span>Flight fare</span>
              <span>AED {basePrice}</span>
            </div>

            <div className="flex items-center justify-between text-gray-600">
              <span>Selected extras</span>
              <span>AED {extrasTotal}</span>
            </div>

            <div className="border-t border-gray-100 pt-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">
                  Total
                </span>

                <span className="text-[20px] font-black text-[#660033]">
                  AED {totalPrice}
                </span>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-4 flex items-center gap-3 rounded-[20px] bg-green-50 p-4">
          <ShieldCheck
            size={22}
            className="shrink-0 text-green-700"
          />

          <div>
            <p className="text-[12px] font-bold text-green-800">
              Extras are optional
            </p>

            <p className="mt-0.5 text-[10px] text-green-700">
              You can continue without adding any extras
            </p>
          </div>
        </section>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-gray-200 bg-white/95 px-4 py-3 backdrop-blur">
        <div className="mx-auto flex w-full max-w-[430px] items-center gap-3">
          <div className="shrink-0">
            <p className="text-[9px] text-gray-500">
              Total
            </p>

            <p className="text-[18px] font-black text-[#660033]">
              AED {totalPrice}
            </p>
          </div>

          <Link
            href={`/flights/payment?flight=${flightId}&extras=${extrasTotal}`}
            className="flex h-[52px] flex-1 items-center justify-center gap-2 rounded-full bg-[#660033] text-[14px] font-bold text-white shadow-md"
          >
            Continue to Payment
            <ChevronRight size={18} />
          </Link>
        </div>
      </div>
    </main>
  );
}
